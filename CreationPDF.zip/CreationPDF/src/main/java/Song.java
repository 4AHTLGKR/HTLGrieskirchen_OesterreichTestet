public class Song {
    public String name;
    public double length;
    public String lyrics;
    public String interpret;

    public Song(String name, double length, String lyrics, String interpret) {
        this.name = name;
        this.length = length;
        this.lyrics = lyrics;
        this.interpret = interpret;
    }
}
